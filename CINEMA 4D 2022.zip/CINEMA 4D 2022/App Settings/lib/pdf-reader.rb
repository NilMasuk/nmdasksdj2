# coding: utf-8
# typed: strict
# frozen_string_literal: true

require "pdf/reader"
